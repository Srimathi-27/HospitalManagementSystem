package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBConnection {

    public static Connection getConnection() {
        Connection connection = null;
        try {
            // Load properties
            Properties props = PropertyUtil.loadProperties("resources/db.properties");
            String host = props.getProperty("hostname");
            String port = props.getProperty("port");
            String db = props.getProperty("dbname");
            String user = props.getProperty("username");
            String pass = props.getProperty("password");

            // Build connection string
            String url = "jdbc:mysql://" + host + ":" + port + "/" + db + "?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";

            // Get connection
            connection = DriverManager.getConnection(url, user, pass);
        } catch (SQLException e) {
            System.out.println("Failed to create database connection!");
            e.printStackTrace();
        } catch (Exception e) {
            System.out.println("Error loading properties!");
            e.printStackTrace();
        }
        return connection;
    }
}