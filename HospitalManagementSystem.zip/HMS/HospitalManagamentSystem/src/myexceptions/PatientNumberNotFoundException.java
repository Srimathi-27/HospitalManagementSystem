package myexceptions;

public class PatientNumberNotFoundException extends Exception {

	private static final long serialVersionUID = 1L;

	public PatientNumberNotFoundException() {
        super("Patient number not found.");
    }

    public PatientNumberNotFoundException(String message) {
        super(message);
    }
}
