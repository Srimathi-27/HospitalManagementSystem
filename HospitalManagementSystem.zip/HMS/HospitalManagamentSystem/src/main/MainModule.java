package main;

import dao.HospitalServiceImpl;
import dao.IHospitalService;
import entity.Appointment;
import myexceptions.PatientNumberNotFoundException;

import java.util.List;
import java.util.Scanner;

public class MainModule {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        IHospitalService service = new HospitalServiceImpl();

        System.out.println("=== Welcome to Hospital Management System ===");

        while (true) {
            System.out.println("\nMENU:");
            System.out.println("1. Get Appointment by ID");
            System.out.println("2. Get Appointments for Patient");
            System.out.println("3. Get Appointments for Doctor");
            System.out.println("4. Schedule an Appointment");
            System.out.println("5. Update an Appointment");
            System.out.println("6. Cancel an Appointment");
            System.out.println("7. Exit");

            System.out.print("Enter choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();  

            try {
                switch (choice) {
                    case 1:
                        System.out.print("Enter Appointment ID: ");
                        int id = scanner.nextInt();
                        Appointment app = service.getAppointmentById(id);
                        if (app != null)
                            System.out.println(app);
                        else
                            System.out.println("Appointment not found.");
                        break;

                    case 2:
                        System.out.print("Enter Patient ID: ");
                        int pid = scanner.nextInt();
                        List<Appointment> patientAppointments = service.getAppointmentsForPatient(pid);
                        patientAppointments.forEach(System.out::println);
                        break;

                    case 3:
                        System.out.print("Enter Doctor ID: ");
                        int did = scanner.nextInt();
                        List<Appointment> doctorAppointments = service.getAppointmentsForDoctor(did);
                        doctorAppointments.forEach(System.out::println);
                        break;

                    case 4:
                        System.out.println("Enter details to schedule:");
                        System.out.print("Appointment ID: ");
                        int aid = scanner.nextInt();
                        System.out.print("Patient ID: ");
                        int newPid = scanner.nextInt();
                        System.out.print("Doctor ID: ");
                        int newDid = scanner.nextInt();
                        scanner.nextLine(); // consume newline
                        System.out.print("Appointment Date (yyyy-mm-dd): ");
                        String date = scanner.nextLine();
                        System.out.print("Description: ");
                        String desc = scanner.nextLine();

                        Appointment newApp = new Appointment(aid, newPid, newDid, date, desc);
                        if (service.scheduleAppointment(newApp))
                            System.out.println("Appointment scheduled successfully.");
                        else
                            System.out.println("Failed to schedule appointment.");
                        break;

                    case 5:
                        System.out.println("Enter details to update:");
                        System.out.print("Appointment ID: ");
                        int uaid = scanner.nextInt();
                        System.out.print("Patient ID: ");
                        int upid = scanner.nextInt();
                        System.out.print("Doctor ID: ");
                        int udid = scanner.nextInt();
                        scanner.nextLine(); // consume newline
                        System.out.print("Appointment Date (yyyy-mm-dd): ");
                        String udate = scanner.nextLine();
                        System.out.print("Description: ");
                        String udesc = scanner.nextLine();

                        Appointment updateApp = new Appointment(uaid, upid, udid, udate, udesc);
                        if (service.updateAppointment(updateApp))
                            System.out.println("Appointment updated successfully.");
                        else
                            System.out.println("Failed to update appointment.");
                        break;

                    case 6:
                        System.out.print("Enter Appointment ID to cancel: ");
                        int cid = scanner.nextInt();
                        if (service.cancelAppointment(cid))
                            System.out.println("Appointment cancelled.");
                        else
                            System.out.println("Appointment not found or already cancelled.");
                        break;

                    case 7:
                        System.out.println("Exiting... Thank you!");
                        scanner.close();
                        System.exit(0);

                    default:
                        System.out.println("Invalid choice!");
                }

            } catch (PatientNumberNotFoundException e) {
                System.out.println("Exception: " + e.getMessage());
            }
            catch (Exception e) {
                System.out.println("Something went wrong: " + e.getMessage());
            }
        }
    }
}