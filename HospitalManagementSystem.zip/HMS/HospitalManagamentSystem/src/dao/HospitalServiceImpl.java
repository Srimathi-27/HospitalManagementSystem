package dao;

import entity.Appointment;
import myexceptions.PatientNumberNotFoundException;
import util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class HospitalServiceImpl implements IHospitalService {

    @Override
    public Appointment getAppointmentById(int appointmentId) {
        Appointment app = null;
        String query = "SELECT * FROM appointment WHERE appointmentId = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setInt(1, appointmentId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    app = new Appointment(
                            rs.getInt("appointmentId"),
                            rs.getInt("patientId"),
                            rs.getInt("doctorId"),
                            rs.getString("appointmentDate"),
                            rs.getString("description")
                    );
                }
            }

        } catch (Exception e) {
            System.out.println("Error fetching appointment: " + e.getMessage());
        }

        return app;
    }

    @Override
    public List<Appointment> getAppointmentsForPatient(int patientId) throws PatientNumberNotFoundException {
        List<Appointment> list = new ArrayList<>();
        String query = "SELECT * FROM appointment WHERE patientId = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setInt(1, patientId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Appointment app = new Appointment(
                            rs.getInt("appointmentId"),
                            rs.getInt("patientId"),
                            rs.getInt("doctorId"),
                            rs.getString("appointmentDate"),
                            rs.getString("description")
                    );
                    list.add(app);
                }
            }

            if (list.isEmpty()) {
                throw new PatientNumberNotFoundException("No appointments found for Patient ID: " + patientId);
            }

        } catch (PatientNumberNotFoundException e) {
            throw e;
        } catch (Exception e) {
            System.out.println("Error fetching appointments for patient: " + e.getMessage());
        }

        return list;
    }

    @Override
    public List<Appointment> getAppointmentsForDoctor(int doctorId) {
        List<Appointment> list = new ArrayList<>();
        String query = "SELECT * FROM appointment WHERE doctorId = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setInt(1, doctorId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Appointment app = new Appointment(
                            rs.getInt("appointmentId"),
                            rs.getInt("patientId"),
                            rs.getInt("doctorId"),
                            rs.getString("appointmentDate"),
                            rs.getString("description")
                    );
                    list.add(app);
                }
            }

        } catch (Exception e) {
            System.out.println("Error fetching appointments for doctor: " + e.getMessage());
        }

        return list;
    }

    @Override
    public boolean scheduleAppointment(Appointment appointment) {
        String query = "INSERT INTO appointment VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setInt(1, appointment.getAppointmentId());
            ps.setInt(2, appointment.getPatientId());
            ps.setInt(3, appointment.getDoctorId());
            ps.setString(4, appointment.getAppointmentDate());
            ps.setString(5, appointment.getDescription());

            int rows = ps.executeUpdate();
            return rows > 0;

        } catch (Exception e) {
            System.out.println("Error scheduling appointment: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean updateAppointment(Appointment appointment) {
        String query = "UPDATE appointment SET patientId = ?, doctorId = ?, appointmentDate = ?, description = ? WHERE appointmentId = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setInt(1, appointment.getPatientId());
            ps.setInt(2, appointment.getDoctorId());
            ps.setString(3, appointment.getAppointmentDate());
            ps.setString(4, appointment.getDescription());
            ps.setInt(5, appointment.getAppointmentId());

            int rows = ps.executeUpdate();
            return rows > 0;

        } catch (Exception e) {
            System.out.println("Error updating appointment: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean cancelAppointment(int appointmentId) {
        String query = "DELETE FROM appointment WHERE appointmentId = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setInt(1, appointmentId);
            int rows = ps.executeUpdate();
            return rows > 0;

        } catch (Exception e) {
            System.out.println("Error cancelling appointment: " + e.getMessage());
            return false;
        }
    }
}